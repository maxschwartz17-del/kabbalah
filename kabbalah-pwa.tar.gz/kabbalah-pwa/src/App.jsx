import { useState, useEffect, useRef } from "react";
import { store } from "./storage.js";

const ELEMENTS=[[1,"H","Hydrogen",1.008],[2,"He","Helium",4.003],[3,"Li","Lithium",6.941],[4,"Be","Beryllium",9.012],[5,"B","Boron",10.81],[6,"C","Carbon",12.011],[7,"N","Nitrogen",14.007],[8,"O","Oxygen",15.999],[9,"F","Fluorine",18.998],[10,"Ne","Neon",20.18],[11,"Na","Sodium",22.99],[12,"Mg","Magnesium",24.305],[13,"Al","Aluminium",26.982],[14,"Si","Silicon",28.086],[15,"P","Phosphorus",30.974],[16,"S","Sulfur",32.06],[17,"Cl","Chlorine",35.45],[18,"Ar","Argon",39.948],[19,"K","Potassium",39.098],[20,"Ca","Calcium",40.078],[21,"Sc","Scandium",44.956],[22,"Ti","Titanium",47.867],[23,"V","Vanadium",50.942],[24,"Cr","Chromium",51.996],[25,"Mn","Manganese",54.938],[26,"Fe","Iron",55.845],[27,"Co","Cobalt",58.933],[28,"Ni","Nickel",58.693],[29,"Cu","Copper",63.546],[30,"Zn","Zinc",65.38],[31,"Ga","Gallium",69.723],[32,"Ge","Germanium",72.63],[33,"As","Arsenic",74.922],[34,"Se","Selenium",78.971],[35,"Br","Bromine",79.904],[36,"Kr","Krypton",83.798],[37,"Rb","Rubidium",85.468],[38,"Sr","Strontium",87.62],[39,"Y","Yttrium",88.906],[40,"Zr","Zirconium",91.224],[41,"Nb","Niobium",92.906],[42,"Mo","Molybdenum",95.95],[43,"Tc","Technetium",98],[44,"Ru","Ruthenium",101.07],[45,"Rh","Rhodium",102.906],[46,"Pd","Palladium",106.42],[47,"Ag","Silver",107.868],[48,"Cd","Cadmium",112.414],[49,"In","Indium",114.818],[50,"Sn","Tin",118.71],[51,"Sb","Antimony",121.76],[52,"Te","Tellurium",127.6],[53,"I","Iodine",126.904],[54,"Xe","Xenon",131.293],[55,"Cs","Caesium",132.905],[56,"Ba","Barium",137.327],[57,"La","Lanthanum",138.905],[58,"Ce","Cerium",140.116],[59,"Pr","Praseodymium",140.908],[60,"Nd","Neodymium",144.242],[61,"Pm","Promethium",145],[62,"Sm","Samarium",150.36],[63,"Eu","Europium",151.964],[64,"Gd","Gadolinium",157.25],[65,"Tb","Terbium",158.925],[66,"Dy","Dysprosium",162.5],[67,"Ho","Holmium",164.93],[68,"Er","Erbium",167.259],[69,"Tm","Thulium",168.934],[70,"Yb","Ytterbium",173.045],[71,"Lu","Lutetium",174.967],[72,"Hf","Hafnium",178.49],[73,"Ta","Tantalum",180.948],[74,"W","Tungsten",183.84],[75,"Re","Rhenium",186.207],[76,"Os","Osmium",190.23],[77,"Ir","Iridium",192.217],[78,"Pt","Platinum",195.084],[79,"Au","Gold",196.967],[80,"Hg","Mercury",200.592],[81,"Tl","Thallium",204.38],[82,"Pb","Lead",207.2],[83,"Bi","Bismuth",208.98],[84,"Po","Polonium",209],[85,"At","Astatine",210],[86,"Rn","Radon",222],[87,"Fr","Francium",223],[88,"Ra","Radium",226],[89,"Ac","Actinium",227],[90,"Th","Thorium",232.038],[91,"Pa","Protactinium",231.036],[92,"U","Uranium",238.029],[93,"Np","Neptunium",237],[94,"Pu","Plutonium",244],[95,"Am","Americium",243],[96,"Cm","Curium",247],[97,"Bk","Berkelium",247],[98,"Cf","Californium",251],[99,"Es","Einsteinium",252],[100,"Fm","Fermium",257],[101,"Md","Mendelevium",258],[102,"No","Nobelium",259],[103,"Lr","Lawrencium",266],[104,"Rf","Rutherfordium",267],[105,"Db","Dubnium",268],[106,"Sg","Seaborgium",269],[107,"Bh","Bohrium",270],[108,"Hs","Hassium",277],[109,"Mt","Meitnerium",278],[110,"Ds","Darmstadtium",281],[111,"Rg","Roentgenium",282],[112,"Cn","Copernicium",285],[113,"Nh","Nihonium",286],[114,"Fl","Flerovium",289],[115,"Mc","Moscovium",290],[116,"Lv","Livermorium",293],[117,"Ts","Tennessine",294],[118,"Og","Oganesson",294]];
const ETYM={1:"Hydro+gen=water-maker. #1=unity, Kether.",6:"Carbon: 6p+6e+6n=666. Mark of the beast. Saturn.",7:"Nitrogen: #7=Netzach. 7 chakras/planets/metals.",8:"Oxygen: #8=Hod. 8=infinity=torus field.",15:"Phosphorus: phos+phoros=LIGHT BEARER=Lucifer.",22:"Titanium: from Titans. #22=Hebrew letters/paths.",26:"Iron(Fe): #26=IHVH. Iron in blood=divine name in veins.",29:"Copper: sacred to Venus(Cyprus). 29->11=two pillars.",33:"Arsenic: #33=vertebrae/Christ Oil/Masonic degrees.",47:"Silver(Ag): sacred to Moon. 47->11.",50:"Tin: sacred to Jupiter. #50=Nun=fish=gateway.",77:"Iridium: from Iris=rainbow goddess. 77=double-7. 7 colors=7 chakras.",79:"Gold(Au): sacred to Sun/Sol/Soul. 79->7=Netzach.",80:"Mercury(Hg): Hermes/Thoth=Mind. 80=Pe=mouth=Word.",82:"Lead(Pb): sacred to Saturn. Lead to Gold=matter to light.",88:"Radium: Ra=sun god. 88=double infinity.",92:"Uranium: Uranus/sky. 92->11=two pillars."};

const HMAP={a:{l:"\u05D0",n:"Aleph",v:1},b:{l:"\u05D1",n:"Beth",v:2},c:{l:"\u05DB",n:"Kaph",v:20},d:{l:"\u05D3",n:"Daleth",v:4},e:{l:"\u05D0",n:"Aleph",v:1},f:{l:"\u05E4",n:"Pe",v:80},g:{l:"\u05D2",n:"Gimel",v:3},h:{l:"\u05D4",n:"He",v:5},i:{l:"\u05D9",n:"Yod",v:10},j:{l:"\u05D9",n:"Yod",v:10},k:{l:"\u05DB",n:"Kaph",v:20},l:{l:"\u05DC",n:"Lamed",v:30},m:{l:"\u05DE",n:"Mem",v:40},n:{l:"\u05E0",n:"Nun",v:50},o:{l:"\u05D5",n:"Vau",v:6},p:{l:"\u05E4",n:"Pe",v:80},q:{l:"\u05E7",n:"Qoph",v:100},r:{l:"\u05E8",n:"Resh",v:200},s:{l:"\u05E1",n:"Samekh",v:60},t:{l:"\u05EA",n:"Tav",v:400},u:{l:"\u05D5",n:"Vau",v:6},v:{l:"\u05D5",n:"Vau",v:6},w:{l:"\u05D5",n:"Vau",v:6},y:{l:"\u05D9",n:"Yod",v:10},z:{l:"\u05D6",n:"Zain",v:7}};
const DIGR={sh:{l:"\u05E9",n:"Shin",v:300},th:{l:"\u05EA",n:"Tav",v:400},ch:{l:"\u05D7",n:"Cheth",v:8},tz:{l:"\u05E6",n:"Tzaddi",v:90},ph:{l:"\u05E4",n:"Pe",v:80}};
const ABET="\u05D0\u05D1\u05D2\u05D3\u05D4\u05D5\u05D6\u05D7\u05D8\u05D9\u05DB\u05DC\u05DE\u05E0\u05E1\u05E2\u05E4\u05E6\u05E7\u05E8\u05E9\u05EA";
const AVS=[1,2,3,4,5,6,7,8,9,10,20,30,40,50,60,70,80,90,100,200,300,400];
const NOT={1:"Kether-unity",3:"Binah-Mother",5:"He-breath;5 senses",7:"Netzach-7 chakras/planets",8:"Hod-torus field",9:"Yesod-Moon",10:"Malkuth-Kingdom",11:"Two pillars",12:"12 zodiac/disciples",13:"Unity+Love",18:"Chai=Life",22:"22 letters/paths",26:"IHVH Tetragrammaton",33:"33 vertebrae/Christ Oil",36:"Double Chai",42:"42-letter Name",72:"72-fold Name",77:"Double Netzach;Iridium/rainbow;7 chakras",79:"Gold=Sun=Soul",82:"Lead=Saturn",86:"Elohim",300:"Shin=Spirit of God",358:"Messiah",400:"Tav=completion",666:"Carbon 666=Saturn"};
const SEP=[null,{n:"Kether",t:"Crown",p:"Primum Mobile",c:"Crown",e:"Spirit"},{n:"Chokmah",t:"Wisdom",p:"Zodiac",c:"Third Eye",e:"Spirit"},{n:"Binah",t:"Understanding",p:"Saturn",c:"Third Eye",e:"Water"},{n:"Chesed",t:"Mercy",p:"Jupiter",c:"Heart",e:"Water"},{n:"Geburah",t:"Strength",p:"Mars",c:"Solar Plexus",e:"Fire"},{n:"Tiphereth",t:"Beauty",p:"Sun",c:"Heart",e:"Air"},{n:"Netzach",t:"Victory",p:"Venus",c:"Sacral",e:"Fire"},{n:"Hod",t:"Splendour",p:"Mercury",c:"Solar Plexus",e:"Water"},{n:"Yesod",t:"Foundation",p:"Moon",c:"Sacral",e:"Air"},{n:"Malkuth",t:"Kingdom",p:"Elements",c:"Root",e:"Earth"}];

const tlit = (name) => {
  const s = name.toLowerCase().replace(/[^a-z]/g,"");
  const r = [];
  let i = 0;
  while(i<s.length){
    const d=s.slice(i,i+2);
    if(DIGR[d]){r.push({roman:d,letter:DIGR[d].l,name:DIGR[d].n,value:DIGR[d].v});i+=2;}
    else if(s[i]==="x"){r.push({roman:"x(k)",letter:"\u05DB",name:"Kaph",value:20});r.push({roman:"x(s)",letter:"\u05E1",name:"Samekh",value:60});i++;}
    else if(HMAP[s[i]]){r.push({roman:s[i],letter:HMAP[s[i]].l,name:HMAP[s[i]].n,value:HMAP[s[i]].v});i++;}
    else{i++;}
  }
  return r;
};
const dRoot = (num) => { let n=num; while(n>9&&n>22) n=String(n).split("").reduce((s,d)=>s+Number(d),0); return n; };
const getS = (num) => { const r=dRoot(num); const i=r===0?10:r>10?r-10:r; return SEP[i]||SEP[1]; };
const fNot = (v) => { const c=[]; if(NOT[v]) c.push({v,note:NOT[v]}); let n=v; while(n>22){n=String(n).split("").reduce((s,d)=>s+Number(d),0);if(n!==v&&NOT[n]){c.push({v:n,note:"->"+n+": "+NOT[n]});break;}} return c; };
const doAth = (ls) => ls.map(lt=>{const ix=ABET.indexOf(lt.letter);if(ix===-1)return{...lt,athbash:lt.letter,athbashValue:lt.value};const m=ABET[ABET.length-1-ix];const mi=ABET.indexOf(m);return{...lt,athbash:m,athbashValue:mi>=0?AVS[mi]:0};});
const doAiq = (ls) => { const CHL={1:"\u05D0",2:"\u05D1",3:"\u05D2",4:"\u05D3",5:"\u05D4",6:"\u05D5",7:"\u05D6",8:"\u05D7",9:"\u05D8"}; return ls.map(lt=>{const ch=lt.value<10?lt.value:lt.value<100?Math.floor(lt.value/10):Math.floor(lt.value/100);return{...lt,chamber:ch,chamberLetter:CHL[ch]||"?"};}); };
const aWord = (w) => { const ls=tlit(w);const v=ls.reduce((s,l)=>s+l.value,0);const r=dRoot(v);const s=getS(r);const at=doAth(ls);const atV=at.reduce((s,l)=>s+l.athbashValue,0);const ai=doAiq(ls);return{word:w,letters:ls,value:v,root:r,sephira:s,ath:at,athVal:atV,athNot:fNot(atV),aiq:ai,aiqW:ai.map(l=>l.chamberLetter).join(""),notable:fNot(v)}; };
const aPhrase = (p) => { const ws=p.trim().split(/\s+/);const as=ws.map(aWord);const tv=as.reduce((s,a)=>s+a.value,0);return{phrase:p,words:as,totalValue:tv,totalRoot:dRoot(tv),totalSephira:getS(dRoot(tv)),initials:as.map(a=>a.letters[0]).filter(Boolean),finals:as.map(a=>a.letters[a.letters.length-1]).filter(Boolean),notable:fNot(tv)}; };

const sH = async(e) => { try{const g=await store.get("kabbalah-history");let h=[];try{if(g?.value)h=JSON.parse(g.value);}catch(x){}h.unshift({...e,ts:new Date().toISOString()});if(h.length>200)h=h.slice(0,200);await store.set("kabbalah-history",JSON.stringify(h));}catch(x){} };
const lH = async() => { try{const g=await store.get("kabbalah-history");return g?.value?JSON.parse(g.value):[];}catch(x){return[];} };
const lF = async() => { try{const g=await store.get("kabbalah-facts");return g?.value?JSON.parse(g.value):[];}catch(x){return[];} };
const sF = async(f) => { try{const g=await store.get("kabbalah-facts");let a=[];try{if(g?.value)a=JSON.parse(g.value);}catch(x){}a.push({...f,ts:new Date().toISOString()});await store.set("kabbalah-facts",JSON.stringify(a));}catch(x){} };

const CL={bg:"#020203",mid:"#07070b",sl:"#0c0c12",gold:"#d4a017",gl:"#ffe566",tx:"#cdd5de",dm:"#8a919b",pr:"#a8b2be",nz:"#2ecc71",ti:"#f39c12",ch:"#5dade2",ye:"#bb8fce",bo:"rgba(212,160,23,0.12)"};
const FN="'EB Garamond',Georgia,serif";
const CI="'Cinzel',serif";
const CO="'Cormorant Garamond',serif";
const iS={background:CL.mid,border:`1px solid ${CL.bo}`,color:CL.tx,padding:"0.6rem 0.8rem",borderRadius:4,fontFamily:FN,fontSize:"1rem",width:"100%",outline:"none"};
const bS={background:CL.gold,color:CL.bg,border:"none",padding:"0.6rem 1.2rem",borderRadius:4,fontFamily:CI,fontSize:"0.75rem",letterSpacing:"0.1em",textTransform:"uppercase",cursor:"pointer",fontWeight:600};
const bD={background:"none",color:CL.dm,border:`1px solid ${CL.bo}`,padding:"0.5rem 1rem",borderRadius:4,fontFamily:CI,fontSize:"0.7rem",letterSpacing:"0.1em",textTransform:"uppercase",cursor:"pointer"};

const Cd=({children,color})=><div style={{background:CL.mid,border:`1px solid ${CL.bo}`,borderRadius:4,padding:"1.2rem",margin:"0.8rem 0",position:"relative",overflow:"hidden"}}><div style={{position:"absolute",top:0,left:0,right:0,height:2,background:color||`linear-gradient(90deg,transparent,${CL.gold},transparent)`,opacity:color?1:0.5}}/>{children}</div>;
const T2=({children})=><h2 style={{fontFamily:CI,fontSize:"1.3rem",fontWeight:400,color:CL.gold,letterSpacing:"0.1em",marginBottom:"1rem",textAlign:"center"}}>{children}</h2>;
const T4=({children})=><h4 style={{fontFamily:CI,fontSize:"0.75rem",letterSpacing:"0.1em",color:CL.gold,textTransform:"uppercase",margin:"0.8rem 0 0.4rem"}}>{children}</h4>;
const NL=({items})=>{if(!items?.length)return null;return<div>{items.map((c,i)=><p key={i} style={{fontSize:"0.82rem",color:CL.dm,margin:"0.2rem 0"}}>{"-> "+c.note}</p>)}</div>;};
const STag=({s})=>{if(!s)return null;return<span style={{color:CL.gl}}>{s.n} ({s.t}) - {s.p} - {s.c} - {s.e}</span>;};
const LTb=({ls})=><table style={{width:"100%",borderCollapse:"collapse",fontSize:"0.88rem"}}><thead><tr>{["Rm","Hb","Name","Val"].map(h=><th key={h} style={{fontFamily:CI,fontSize:"0.55rem",letterSpacing:"0.1em",textTransform:"uppercase",color:CL.gold,borderBottom:`1px solid ${CL.bo}`,padding:"0.4rem",textAlign:"left"}}>{h}</th>)}</tr></thead><tbody>{ls.map((l,i)=><tr key={i}><td style={{padding:"0.3rem",borderBottom:"1px solid rgba(212,160,23,0.04)"}}>{l.roman.toUpperCase()}</td><td style={{padding:"0.3rem",borderBottom:"1px solid rgba(212,160,23,0.04)",fontSize:"1.1rem",color:CL.gold,fontFamily:"serif"}}>{l.letter}</td><td style={{padding:"0.3rem",borderBottom:"1px solid rgba(212,160,23,0.04)",color:CL.dm}}>{l.name}</td><td style={{padding:"0.3rem",borderBottom:"1px solid rgba(212,160,23,0.04)"}}>{l.value}</td></tr>)}</tbody></table>;
const WR=({data:d})=><div><Cd><T4>{`Gematria - ${d.word}`}</T4><LTb ls={d.letters}/><p>Total: <strong style={{fontFamily:CI,color:CL.gl,fontSize:"1.2rem"}}>{d.value}</strong> | Root: <strong style={{color:CL.gl}}>{d.root}</strong> {"->"} <STag s={d.sephira}/></p><NL items={d.notable}/></Cd><Cd><T4>Athbash</T4><div style={{display:"flex",gap:"0.8rem",flexWrap:"wrap"}}>{d.ath.map((l,i)=><div key={i} style={{textAlign:"center"}}><div style={{color:CL.gold,fontFamily:"serif"}}>{l.letter}</div><div style={{color:CL.dm,fontSize:"0.6rem"}}>v</div><div style={{color:CL.ti,fontFamily:"serif"}}>{l.athbash}</div></div>)}</div><p>Value: <strong style={{color:CL.gl}}>{d.athVal}</strong></p><NL items={d.athNot}/></Cd><Cd><T4>AIQ BKR</T4><div style={{display:"flex",gap:"0.8rem",flexWrap:"wrap"}}>{d.aiq.map((l,i)=><div key={i} style={{textAlign:"center"}}><div style={{color:CL.gold,fontFamily:"serif"}}>{l.letter}</div><div style={{color:CL.dm,fontSize:"0.55rem"}}>{`${l.value}->${l.chamber}`}</div><div style={{color:CL.nz,fontFamily:"serif"}}>{l.chamberLetter}</div></div>)}</div><p>Reduced: <span style={{color:CL.gold,fontFamily:"serif"}}>{d.aiqW}</span></p></Cd></div>;

const respondToQuestion = (input, low, facts) => {
  const out = [];
  if (low.includes("athbash") || low.includes("temura")) {
    out.push("Temura is the art of letter substitution. Athbash mirrors each letter to its opposite in the alphabet -- Aleph becomes Tav, Beth becomes Shin. This reveals the hidden face of a word. Enter the word in the Word Analyzer and the Athbash transformation will appear letter by letter.\n\nAthbash is most powerful when the mirrored word reveals something unexpected -- a hidden name, a complementary concept, or a value that connects to something you already know.");
  } else if (low.includes("notariqon")) {
    out.push("Notariqon takes the first (or last) letter of each word in a phrase and reads them as a new word. It reveals what a phrase is secretly spelling. Use the Phrase Decoder -- it will show both the initials and finals as Hebrew words with their own values.\n\nThis is the right tool when you have a verse, a title, or a sentence that feels significant.");
  } else if (low.includes("aiq") || low.includes("nine chamber")) {
    out.push("AIQ BKR reduces every letter to its unit value: Aleph(1), Yod(10), and Qoph(100) all become 1. This strips away magnitude and reveals essential quality -- which letters are secretly siblings. Use the Word Analyzer to see this reduction.");
  } else if (low.includes("gematria")) {
    out.push("Gematria reveals equivalence between words sharing the same value. But it is one tool among several. Use Gematria when you want to know what a word EQUALS, Athbash when you want what it MIRRORS, Notariqon when you want what a phrase CONCEALS, and AIQ BKR when you want what a letter ESSENTIALLY IS.\n\nThe right tool depends on the question you are asking.");
  } else if (low.includes("element") || low.includes("periodic")) {
    out.push("Each element's atomic number maps to a Sephira through its digital root. The etymologies often carry esoteric weight: Phosphorus means 'light bearer' (Lucifer), Iron is #26 (IHVH in your blood), Iridium #77 is from Iris, goddess of the rainbow. Explore these in the Elements tab.");
  } else if (low.includes("how") || low.includes("should") || low.includes("practice")) {
    out.push("Understanding comes through three channels: study (correspondences), practice (meditation, journaling, contemplation), and experience (attention to signs in daily life).\n\nWhat specifically are you trying to deepen? I can point you to the right tool or practice.");
  } else {
    const sigWords = input.split(/\s+/).filter(w => w.replace(/[^a-zA-Z]/g,"").length > 3).slice(0, 3);
    out.push("That is a worthy question.\n");
    if (sigWords.length > 0) {
      const w = sigWords[0].replace(/[^a-zA-Z]/g,"");
      const an = aWord(w);
      out.push(`The key term "${w}" carries a value of ${an.value} (${an.sephira.n}). ${an.notable.length ? an.notable[0].note + "." : ""}`);
    }
    out.push("\nCan you tell me more about what prompted this? Whether it arose from study, a dream, or something you witnessed will help me apply the right lens.");
  }
  return out.join("\n");
};

const respondToVision = (input, low, facts) => {
  const out = [];
  const nums = []; let nm; const numRe = /\b(\d+)\b/g;
  while ((nm = numRe.exec(input)) !== null) { const n = parseInt(nm[1]); if (n > 0 && n < 100000) nums.push(n); }
  const uniqNums = [...new Set(nums)];
  const skip = new Set(["the","and","was","is","are","were","with","that","this","for","but","not","has","had","have","been","being","from","its","also","which","while","along","last","many","seen","saw","today","yesterday","additionally","equal","reading","solving","sticker","very","just","really","about","there","their","they","them","than","then","what","when","where","how","who","can","could","would","should","will","shall","may","might","much","more","most","some","any","all","each","every","both","few","into","onto","upon","over","under","after","before","during","between","through","because","since","until","here","now","still","already","again","too","only","even","like","such","other","another","same","these","those","something","anything","everything","nothing","someone","anyone","everyone","doing","going","said","told","know","knew","think","thought","make","made","take","took","come","came","went","look","looked","want","give","use","find","found"]);
  const sigWords = []; input.split(/\s+/).forEach(w => { const c = w.replace(/[^a-zA-Z]/g,""); if (!c || c.length <= 2 || skip.has(c.toLowerCase())) return; sigWords.push(c); });
  const uniqWords = [...new Set(sigWords)];

  const themes = {};
  if (low.includes("kerubim") || low.includes("cherubim")) themes.kerubim = true;
  if (low.includes("four") || uniqNums.includes(4)) themes.four = true;
  if (low.includes("three") || low.includes("trefoil") || low.includes("trinity")) themes.three = true;
  if (low.includes("genesis") || low.includes("beginning")) themes.genesis = true;
  if (/\bred\b|\bblue\b|\bgreen\b|\byellow\b|\borange\b|\bwhite\b|\bblack\b/.test(low)) themes.colors = true;
  if (low.includes("initial") || /\b[A-Z]{2,5}\b/.test(input)) themes.initials = true;
  if (low.includes("dream")) themes.dream = true;
  if (low.includes("death") || low.includes("died")) themes.death = true;
  if (low.includes("heart") || low.includes("love")) themes.heart = true;
  if (low.includes("christ") || low.includes("pineal") || low.includes("kundalini") || low.includes("oil")) themes.christoil = true;
  if (low.includes("saturn") || low.includes("cube") || low.includes("time")) themes.saturn = true;
  if (low.includes("torus") || low.includes("field") || low.includes("magnet")) themes.torus = true;

  const themeKeys = Object.keys(themes);
  const isRich = themeKeys.length >= 2 || input.length > 150;

  if (isRich) out.push("You are describing a convergence of signs. Let me draw out what matters most.\n");
  else if (themeKeys.length === 1) out.push("I hear you. Let me speak to what the tradition says.\n");
  else out.push("Let me look at this carefully.\n");

  if (themes.kerubim) {
    out.push("The Kerubim are the four living creatures of Ezekiel's vision -- Bull (Taurus/Earth), Lion (Leo/Fire), Eagle (Scorpio/Water), Man (Aquarius/Air). They are the four modes through which divine energy stabilizes in creation: the four letters of IHVH, the four worlds, the four fixed zodiac points. When this pattern repeats around you, the wholeness of creation is asserting itself.\n");
    out.push("Which of the four faces feels most dominant in your life right now? The Bull (stability), the Lion (will), the Eagle (transformation), or the Man (knowledge)?\n");
  }
  if (themes.four && !themes.kerubim) {
    out.push("Four is Chesed -- Mercy, the first Sephira below the Abyss, where the abstract becomes concrete. It is also the Tetragrammaton, the four elements, the four worlds. When four repeats, something is solidifying -- potential becoming real.\n");
  }
  if (themes.three) {
    out.push("Three is Binah, the Great Mother. The three pillars of the Tree -- Severity, Mercy, Equilibrium -- are the skeleton of reality. A trefoil is the Trinity in geometry. If your initials appeared inside it, the tradition says your identity is being held by the three supernal forces.\n");
  }
  if (themes.genesis) {
    out.push("Bereshith -- 'In the beginning.' BRAShITh contains BRA (created) and ShITh (six/foundation). When Genesis appears at the close of a sequence of signs, it names what the vision created. The signs were the days of making; Genesis is the declaration that it is done.\n");
  }
  if (themes.colors) {
    out.push("Colors are planetary forces made visible:");
    if (/\bred\b/.test(low)) out.push("  Red: Mars/Geburah -- severity, the power to cut.");
    if (/\borange\b/.test(low)) out.push("  Orange: Sun-Mars bridge, warm severity.");
    if (/\bblue\b/.test(low)) out.push("  Blue: Jupiter/Chesed (mercy) or Moon/Yesod.");
    if (/\bgreen\b/.test(low)) out.push("  Green: Venus/Netzach -- growth, enduring love.");
    if (/\byellow\b/.test(low)) out.push("  Yellow: Sun/Tiphereth -- the heart where all forces harmonize.");
    if (/\bwhite\b/.test(low)) out.push("  White: Kether/Moon -- undifferentiated light.");
    if (/\bblack\b/.test(low)) out.push("  Black: Binah/Saturn -- the womb of form.");
    out.push("When multiple colors appear together, the arrangement is a sentence written in light.\n");
  }
  if (themes.dream) {
    out.push("Dreams operate in the astral plane where the Ruach speaks to the Nephesch through symbols. Note the strongest image and bring it here as a single word -- its Gematria will often reveal what the dream was really about.\n");
  }
  if (themes.christoil) {
    out.push("The Christ Oil descends monthly from the claustrum and, if preserved, ascends 33 vertebrae to illuminate the pineal. This is the literal resurrection -- not of a body, but of consciousness from matter.\n");
  }
  if (themes.saturn) {
    out.push("Saturn is Binah, Chronos, the classroom. Carbon 6-6-6 is his mark. The cube is his geometry. To transcend Saturn is to graduate -- mind over matter instead of matter over mind.\n");
  }

  const meaningfulNums = uniqNums.filter(n => fNot(n).length > 0 || ELEMENTS.find(e => e[0] === n));
  if (meaningfulNums.length > 0 && meaningfulNums.length <= 4) {
    meaningfulNums.forEach(num => {
      const s = getS(num); const nt = fNot(num); const el = ELEMENTS.find(e => e[0] === num);
      if (nt.length || el) {
        let line = `${num}`;
        if (dRoot(num) !== num) line += ` (root ${dRoot(num)})`;
        line += `: ${s.n}/${s.t}.`;
        if (nt.length) line += ` ${nt[0].note}.`;
        if (el && ETYM[el[0]]) line += ` As ${el[2]}: ${ETYM[el[0]]}`;
        out.push(line);
      }
    });
    out.push("");
  }

  const wordData = uniqWords.slice(0, 10).map(w => ({ w, ...aWord(w) }));
  const valMap = {}; wordData.forEach(wd => { if (!valMap[wd.value]) valMap[wd.value] = []; valMap[wd.value].push(wd.w); });
  const equivs = Object.entries(valMap).filter(([v, ws]) => ws.length > 1);
  if (equivs.length > 0) {
    equivs.forEach(([v, ws]) => out.push(`Hidden connection: ${ws.map(w => '"' + w + '"').join(" and ")} share the value ${v}. In the tradition, words of equal value are secretly the same thing. Sit with what these two share.`));
    out.push("");
  }

  const relFacts = facts.filter(f => { const fl = (f.fact || "").toLowerCase(); return uniqWords.some(w => fl.includes(w.toLowerCase())) || uniqNums.some(n => fl.includes(String(n))); });
  if (relFacts.length) out.push(`This connects to what you have stored: ${relFacts.map(f => f.fact).join("; ")}\n`);

  if (isRich) {
    const qs = [];
    if (themes.kerubim || themes.four) qs.push("Of the four manifestations, which arrived with the strongest feeling? That is the face turned toward you.");
    if (themes.colors) qs.push("Were the colors presented to you, or did you choose them? Whether the sign is given or made changes its meaning.");
    if (themes.initials) qs.push("How did you feel when you saw your initials? The emotional response is the Nephesch confirming what the Ruach perceived.");
    if (themes.genesis) qs.push("Is something in your life beginning right now? The signs often name what the conscious mind has not yet acknowledged.");
    if (!qs.length) qs.push("What felt most significant in the moment -- not in analysis, but in the body? The first sign that made your breath catch is the one that matters most.");
    out.push(qs[0]);
  } else if (themeKeys.length > 0) {
    out.push("Tell me more about the context -- when and where this appeared will help me interpret it fully.");
  } else {
    out.push("Help me serve this well:");
    out.push("- Are you describing a synchronicity, studying a concept, or processing a feeling?");
    out.push("- Is there a specific word, name, or number you want examined more closely?");
    out.push("\nGematria reveals equivalence. Athbash reveals the mirror. Notariqon reveals the hidden word. The Tree reveals the structure. The right tool depends on the question.");
  }

  if (out.length <= 2) {
    const an = aWord(input);
    return `"${input}" carries a value of ${an.value} (${an.sephira.n}). ${an.notable.length ? an.notable[0].note : ""}\n\nTell me more about what brought this to mind, and I will know which lens to apply.`;
  }
  return out.join("\n");
};

const oracleRespond = (input, facts) => {
  const low = input.toLowerCase().trim();
  if (low.includes("remember") || low.includes("save this") || low.includes("fact:") || low.includes("note:") || low.startsWith("remember")) return "SAVE:" + input;

  const pureNum = low.match(/^(\d+)$/);
  if (pureNum) {
    const num = parseInt(pureNum[1]); const s = getS(num); const r = dRoot(num); const nt = fNot(num); const el = ELEMENTS.find(e => e[0] === num); const rf = facts.filter(f => f.fact?.includes(String(num)));
    let resp = `${num} carries the vibration of ${s.n}, the ${s.t}.`; if (r !== num) resp += ` Its digits reduce to ${r}.`; resp += ` This is the sphere of ${s.p}, felt at the ${s.c} Chakra as ${s.e}.`;
    if (nt.length) resp += `\n\n${nt.map(n => n.note).join(". ")}.`;
    if (el) { resp += `\n\nIn matter, ${num} manifests as ${el[2]} (${el[1]}).`; if (ETYM[num]) resp += ` ${ETYM[num]}`; }
    if (rf.length) resp += `\n\nYou have noted: ${rf.map(f => f.fact).join("; ")}`;
    resp += `\n\nIs this number appearing in your life, or are you studying it? The context determines whether Gematria, the element correspondence, or the Sephirotic position is the right lens.`;
    return resp;
  }

  const elMatch = ELEMENTS.find(e => low === e[2].toLowerCase() || low === e[1].toLowerCase());
  if (elMatch) {
    const eS = getS(dRoot(elMatch[0])); const na = aWord(elMatch[2]);
    let resp = `${elMatch[2]}, element ${elMatch[0]}, dwells in ${eS.n} (${eS.t}) through root ${dRoot(elMatch[0])}.`;
    if (ETYM[elMatch[0]]) resp += `\n\n${ETYM[elMatch[0]]}`;
    resp += `\n\nIts name sums to ${na.value} in Gematria (${na.sephira.n}). What drew you to this element?`;
    return resp;
  }

  const wc = low.split(/\s+/).filter(w => w.length > 0).length;
  if (wc <= 2 && !low.includes("?") && low.length < 40) {
    const an = aWord(input.trim()); const resp = [];
    resp.push(`"${input.trim()}" vibrates at ${an.value}, the frequency of ${an.sephira.n} (${an.sephira.t}).`);
    if (an.root !== an.value) resp.push(`Its digits compress to ${an.root}.`);
    resp.push(`On the Tree: ${an.sephira.p}, ${an.sephira.c} Chakra, ${an.sephira.e}.`);
    if (an.notable.length) resp.push(`\n${an.notable.map(n => n.note).join(". ")}.`);
    const el = ELEMENTS.find(e => e[0] === an.value);
    if (el) { resp.push(`\n${an.value} is also ${el[2]} on the periodic table.`); if (ETYM[an.value]) resp.push(ETYM[an.value]); }
    resp.push(`\nTo go deeper: the Word Analyzer shows the full Hebrew letter-by-letter breakdown. If this is a name, Athbash will reveal its mirror. If it appeared in a phrase, Notariqon in the Phrase Decoder may reveal what the phrase is secretly spelling.\n\nWhere did you encounter this word?`);
    return resp.join("\n");
  }

  if (low.includes("?")) return respondToQuestion(input, low, facts);
  return respondToVision(input, low, facts);
};

const speakText = (text) => {
  if (!window.speechSynthesis) return;
  window.speechSynthesis.cancel();
  const clean = text.replace(/[^\w\s.,;:!?'-]/g, " ").replace(/\s+/g, " ");
  // Split into chunks under 200 chars for mobile compatibility
  const sentences = clean.match(/[^.!?]+[.!?]+|[^.!?]+$/g) || [clean];
  let chunk = "";
  const chunks = [];
  sentences.forEach(s => {
    if ((chunk + s).length > 180) { if (chunk) chunks.push(chunk.trim()); chunk = s; }
    else { chunk += s; }
  });
  if (chunk) chunks.push(chunk.trim());
  chunks.forEach((c, i) => {
    const utt = new SpeechSynthesisUtterance(c);
    utt.rate = 0.9;
    utt.pitch = 0.95;
    window.speechSynthesis.speak(utt);
  });
};

const stopSpeaking = () => { if (window.speechSynthesis) window.speechSynthesis.cancel(); };

const OracleTab = () => {
  const [msgs, setMsgs] = useState([{role:"assistant",content:"Peace be upon you, seeker.\n\nI am here to help you see what is hidden in plain sight. Share with me what you have witnessed -- the numbers that followed you, the words that caught your eye, the patterns that repeated -- and I will show you what the letters and the spheres have to say about it.\n\nYou may also enter a single word, a name, a number, or an element, and I will reveal its place on the Tree.\n\nTo teach me a fact, begin with 'remember:' and I will hold it.\n\nSpeak, and I will listen."}]);
  const [oInp, setOInp] = useState("");
  const [facts, setFacts] = useState([]);
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const recognRef = useRef(null);
  const endRef = useRef(null);

  useEffect(()=>{lF().then(f=>setFacts(f));},[]);
  useEffect(()=>{endRef.current?.scrollIntoView({behavior:"smooth"});},[msgs]);

  // Setup speech recognition
  useEffect(() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SR) {
      const recog = new SR();
      recog.continuous = false;
      recog.interimResults = false;
      recog.lang = "en-US";
      recog.onresult = (e) => {
        const transcript = e.results[0][0].transcript;
        setOInp(prev => prev ? prev + " " + transcript : transcript);
        setListening(false);
      };
      recog.onerror = () => setListening(false);
      recog.onend = () => setListening(false);
      recognRef.current = recog;
    }
    return () => stopSpeaking();
  }, []);

  const toggleDictation = () => {
    if (!recognRef.current) return;
    if (listening) { recognRef.current.stop(); setListening(false); }
    else { recognRef.current.start(); setListening(true); }
  };

  const toggleSpeak = (text) => {
    if (speaking) { stopSpeaking(); setSpeaking(false); }
    else { speakText(text); setSpeaking(true); setTimeout(() => setSpeaking(false), text.length * 60); }
  };

  const send = async () => {
    if (!oInp.trim()) return;
    stopSpeaking();
    setSpeaking(false);
    const newMsgs = [...msgs, {role:"user",content:oInp.trim()}];
    setMsgs(newMsgs);
    const inp = oInp.trim();
    setOInp("");
    let response = oracleRespond(inp, facts);
    if (response.startsWith("SAVE:")) {
      const ft = response.slice(5);
      await sF({fact:ft});
      const upd = await lF();
      setFacts(upd);
      response = `Remembered: '${ft}'\n\nI now hold ${upd.length} fact${upd.length>1?"s":""} in memory.`;
    }
    setMsgs([...newMsgs, {role:"assistant",content:response}]);
    await sH({type:"oracle",input:inp,response:response.slice(0,200)});
  };

  const micBtnStyle = {
    background: listening ? CL.gold : "none",
    color: listening ? CL.bg : CL.dm,
    border: `1px solid ${listening ? CL.gold : CL.bo}`,
    borderRadius: "50%",
    width: 38, height: 38,
    display: "flex", alignItems: "center", justifyContent: "center",
    cursor: "pointer", flexShrink: 0, fontSize: "1.1rem",
    transition: "all 0.3s",
  };

  const speakBtnStyle = {
    background: "none", border: "none", color: CL.dm, cursor: "pointer",
    fontSize: "0.7rem", fontFamily: CI, letterSpacing: "0.08em",
    padding: "0.2rem 0.4rem", opacity: 0.7,
  };

  return (<div style={{display:"flex",flexDirection:"column",height:"calc(100vh - 200px)",minHeight:400}}>
    <T2>The Oracle</T2>
    {facts.length>0&&<div style={{fontSize:"0.7rem",color:CL.dm,textAlign:"center",marginBottom:"0.5rem"}}>{facts.length} remembered fact{facts.length>1?"s":""}</div>}
    <div style={{flex:1,overflow:"auto",padding:"0 0.3rem",marginBottom:"0.8rem"}}>
      {msgs.map((m,i)=>(<div key={i} style={{marginBottom:"0.8rem",padding:"0.7rem 0.9rem",borderRadius:6,background:m.role==="user"?CL.sl:CL.mid,borderLeft:m.role==="assistant"?`2px solid ${CL.gold}`:"none",maxWidth:"92%",marginLeft:m.role==="user"?"auto":0}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div style={{fontSize:"0.55rem",fontFamily:CI,letterSpacing:"0.1em",textTransform:"uppercase",color:m.role==="user"?CL.dm:CL.gold,marginBottom:"0.2rem"}}>{m.role==="user"?"You":"Oracle"}</div>
          {m.role==="assistant"&&i>0&&<button style={speakBtnStyle} onClick={()=>toggleSpeak(m.content)} title="Read aloud">{speaking?"Stop":"Listen"}</button>}
        </div>
        <div style={{whiteSpace:"pre-wrap",lineHeight:1.7,color:CL.tx,fontSize:"0.92rem"}}>{m.content}</div>
      </div>))}
      <div ref={endRef}/>
    </div>
    <div style={{display:"flex",gap:"0.5rem",alignItems:"center"}}>
      <button style={micBtnStyle} onClick={toggleDictation} title={listening?"Stop dictation":"Start dictation"}>
        {listening ? "Stop" : "Mic"}
      </button>
      <input style={iS} value={oInp} onChange={e=>setOInp(e.target.value)} placeholder={listening?"Listening...":"Enter a word, number, element, phrase, or fact..."} onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey)send();}}/>
      <button style={bS} onClick={send}>Ask</button>
    </div>
    {!recognRef.current&&<div style={{fontSize:"0.6rem",color:CL.dm,textAlign:"center",marginTop:"0.3rem"}}>Voice input not available on this device</div>}
  </div>);
};

const WordTab = () => { const [inp,si]=useState("");const [res,sr]=useState(null);const run=async()=>{if(!inp.trim())return;const d=aWord(inp.trim());sr(d);await sH({type:"word",input:inp.trim(),value:d.value,sephira:d.sephira?.n});};return(<div><T2>Word Analyzer</T2><div style={{display:"flex",gap:"0.8rem",marginBottom:"1.5rem"}}><input style={iS} value={inp} onChange={e=>si(e.target.value)} placeholder="Enter a word or name..." onKeyDown={e=>{if(e.key==="Enter")run();}}/><button style={bS} onClick={run}>Analyze</button></div>{res&&<WR data={res}/>}</div>); };
const PhraseTab = () => { const [inp,si]=useState("");const [res,sr]=useState(null);const run=async()=>{if(!inp.trim())return;const d=aPhrase(inp.trim());sr(d);await sH({type:"phrase",input:inp.trim(),value:d.totalValue,sephira:d.totalSephira?.n});};return(<div><T2>Phrase Decoder</T2><div style={{display:"flex",gap:"0.8rem",marginBottom:"1.5rem"}}><input style={iS} value={inp} onChange={e=>si(e.target.value)} placeholder="Enter a phrase..." onKeyDown={e=>{if(e.key==="Enter")run();}}/><button style={bS} onClick={run}>Decode</button></div>{res&&<div>{res.words.map((w,i)=><WR key={i} data={w}/>)}<Cd color={CL.ti}><T4>{`Full Phrase: ${res.totalValue}`}</T4><p>Root: <strong style={{color:CL.gl}}>{res.totalRoot}</strong> {"->"} <STag s={res.totalSephira}/></p><NL items={res.notable}/>{res.initials.length>0&&<div style={{marginTop:"0.8rem",borderTop:`1px solid ${CL.bo}`,paddingTop:"0.6rem"}}><T4>Notariqon - Initials</T4><p style={{fontSize:"1.2rem",color:CL.gold,fontFamily:"serif"}}>{res.initials.map(l=>l.letter).join("")} = {res.initials.reduce((s,l)=>s+l.value,0)}</p><T4>Notariqon - Finals</T4><p style={{fontSize:"1.2rem",color:CL.gold,fontFamily:"serif"}}>{res.finals.map(l=>l.letter).join("")} = {res.finals.reduce((s,l)=>s+l.value,0)}</p></div>}</Cd></div>}</div>); };
const CompTab = () => { const [cA,sA]=useState("");const [cB,sB]=useState("");const [res,sr]=useState(null);const run=async()=>{if(!cA.trim()||!cB.trim())return;const ra=aWord(cA.trim()),rb=aWord(cB.trim());sr({a:ra,b:rb});await sH({type:"compare",inputA:cA.trim(),inputB:cB.trim(),valueA:ra.value,valueB:rb.value});};return(<div><T2>Comparator</T2><div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"0.8rem",marginBottom:"1rem"}}><input style={iS} value={cA} onChange={e=>sA(e.target.value)} placeholder="First word..."/><input style={iS} value={cB} onChange={e=>sB(e.target.value)} placeholder="Second word..."/></div><div style={{textAlign:"center",marginBottom:"1rem"}}><button style={bS} onClick={run}>Compare</button></div>{res&&<div><div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"0.8rem"}}><WR data={res.a}/><WR data={res.b}/></div><Cd color={res.a.value===res.b.value?CL.nz:CL.ti}><T4>Relationship</T4>{res.a.value===res.b.value?<p style={{color:CL.nz}}>Qabalistic equivalents - same value ({res.a.value})</p>:<div><p>Diff: <strong style={{color:CL.gl}}>{Math.abs(res.a.value-res.b.value)}</strong> | Sum: <strong style={{color:CL.gl}}>{res.a.value+res.b.value}</strong></p>{res.a.root===res.b.root&&<p style={{color:CL.nz}}>Same root ({res.a.root})</p>}</div>}</Cd></div>}</div>); };

const ElemTab = () => {
  const [q,sq]=useState("");const [sel,ss]=useState(null);
  const filtered=q?ELEMENTS.filter(e=>e[2].toLowerCase().includes(q.toLowerCase())||e[1].toLowerCase().includes(q.toLowerCase())||String(e[0])===q):ELEMENTS;
  const pick=(el)=>ss({num:el[0],sym:el[1],name:el[2],wt:el[3],root:dRoot(el[0]),sephira:getS(dRoot(el[0])),etym:ETYM[el[0]]||null,notable:fNot(el[0]),na:aWord(el[2])});
  return(<div><T2>Elements</T2><input style={iS} value={q} onChange={e=>sq(e.target.value)} placeholder="Search by name, symbol, or number..."/><div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(52px,1fr))",gap:3,margin:"1rem 0",maxHeight:sel?200:"none",overflow:sel?"auto":"visible"}}>{filtered.map(el=><div key={el[0]} onClick={()=>pick(el)} style={{background:sel?.num===el[0]?CL.gold:CL.mid,color:sel?.num===el[0]?CL.bg:CL.tx,border:`1px solid ${CL.bo}`,borderRadius:3,padding:"0.3rem",textAlign:"center",cursor:"pointer",fontSize:"0.7rem"}}><div style={{fontWeight:700,fontSize:"0.8rem"}}>{el[1]}</div><div style={{fontSize:"0.55rem",color:sel?.num===el[0]?CL.bg:CL.dm}}>{el[0]}</div></div>)}</div>{sel&&<div><Cd color={CL.gold}><div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}><div><div style={{fontSize:"2.5rem",fontFamily:CI,color:CL.gold}}>{sel.sym}</div><div style={{fontFamily:CO,fontSize:"1.3rem",color:CL.gl}}>{sel.name}</div></div><div style={{textAlign:"right"}}><div style={{color:CL.dm,fontSize:"0.85rem"}}>#{sel.num} | {sel.wt} u</div><div style={{color:CL.dm,fontSize:"0.85rem"}}>Root: {sel.root} {"->"} <STag s={sel.sephira}/></div></div></div><NL items={sel.notable}/>{sel.etym&&<div style={{marginTop:"0.8rem",padding:"0.8rem",background:CL.bg,borderRadius:4,border:`1px solid ${CL.bo}`}}><T4>Esoteric Etymology</T4><p style={{color:CL.pr,fontSize:"0.9rem"}}>{sel.etym}</p></div>}</Cd><T4>{`Gematria: ${sel.name}`}</T4><WR data={sel.na}/></div>}</div>);
};

const PracTab = () => {
  const daily=[{i:"\u05D0",t:"Morning Divine Names",x:"Recite 10 Names, visualize Tree Kether to Malkuth."},{i:"\u05D1",t:"Negative Existence",x:"10 min: AIN, AIN SVP, AIN SVP AVR."},{i:"\u05D2",t:"Gematria Journal",x:"Calculate one word, find its equivalent."},{i:"\u05D3",t:"Triadic Assessment",x:"Rate Choice/Execution/Moderation."},{i:"\u05D4",t:"Equilibrium",x:"Hold one polarity, seek the centre."},{i:"\u05D5",t:"Christ Oil Awareness",x:"Alkaline diet, retention, fasting."}];
  const weekly=[{i:"\u05D6",t:"Sephirotic Study",x:"One Sephira/week: Name, angels, planet."},{i:"\u05D7",t:"IHVH Body Map",x:"Yod=head, He=arms, Vau=body, He=legs."},{i:"\u05D8",t:"Kundalini Integration",x:"Creative practice: call-response, solo, free."},{i:"\u05D9",t:"Kerubic Visualization",x:"4 Kerubim at cardinal directions."}];
  const Row=({p})=><div style={{display:"flex",gap:"0.6rem",margin:"0.4rem 0",padding:"0.4rem"}}><div style={{flexShrink:0,width:28,height:28,border:`1px solid ${CL.gold}`,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"0.75rem",color:CL.gold}}>{p.i}</div><div style={{color:CL.pr,fontSize:"0.9rem"}}><strong style={{color:CL.gold,fontFamily:CO}}>{p.t}</strong>{" - "+p.x}</div></div>;
  return(<div><T2>Practices</T2><h3 style={{fontFamily:CO,fontSize:"1.1rem",color:CL.gl,margin:"1.2rem 0 0.4rem",paddingLeft:"0.6rem",borderLeft:`2px solid ${CL.gold}`}}>Daily</h3>{daily.map((p,i)=><Row key={i} p={p}/>)}<h3 style={{fontFamily:CO,fontSize:"1.1rem",color:CL.gl,margin:"1.2rem 0 0.4rem",paddingLeft:"0.6rem",borderLeft:`2px solid ${CL.gold}`}}>Weekly</h3>{weekly.map((p,i)=><Row key={i} p={p}/>)}</div>);
};

const HistTab = () => {
  const [items,setItems]=useState([]);const [loaded,setLoaded]=useState(false);
  useEffect(()=>{lH().then(h=>{setItems(h);setLoaded(true);});},[]);
  const colors={word:CL.ch,phrase:CL.nz,compare:CL.ti,oracle:CL.ye};
  if(!loaded)return<p style={{color:CL.dm,textAlign:"center"}}>Loading...</p>;
  return(<div><T2>History</T2><div style={{display:"flex",justifyContent:"space-between",marginBottom:"0.8rem"}}><span style={{color:CL.dm,fontSize:"0.8rem"}}>{items.length} saved</span>{items.length>0&&<button style={bD} onClick={async()=>{try{await store.del("kabbalah-history");}catch(x){}setItems([]);}}>Clear</button>}</div>{!items.length&&<p style={{color:CL.dm,textAlign:"center",padding:"2rem 0"}}>No analyses yet.</p>}{items.map((it,i)=><div key={i} style={{display:"flex",gap:"0.6rem",padding:"0.5rem 0",borderBottom:`1px solid ${CL.bo}`}}><div style={{fontFamily:CI,fontSize:"0.5rem",letterSpacing:"0.08em",textTransform:"uppercase",color:colors[it.type]||CL.gold,minWidth:40}}>{it.type}</div><div style={{flex:1}}><div style={{color:CL.tx,fontSize:"0.85rem"}}>{it.input||it.inputA}{it.inputB?` <-> ${it.inputB}`:""}</div>{it.value!==undefined&&<div style={{color:CL.dm,fontSize:"0.75rem"}}>{`${it.value} -> ${it.sephira||""}`}</div>}{it.response&&<div style={{color:CL.dm,fontSize:"0.75rem",fontStyle:"italic"}}>{it.response}...</div>}</div><div style={{color:CL.dm,fontSize:"0.65rem"}}>{it.ts?new Date(it.ts).toLocaleDateString():""}</div></div>)}</div>);
};

const TABS=[{id:"oracle",lb:"Oracle"},{id:"word",lb:"Word"},{id:"phrase",lb:"Phrase"},{id:"compare",lb:"Compare"},{id:"elements",lb:"Elements"},{id:"practices",lb:"Practices"},{id:"history",lb:"History"}];

export default function App(){
  const [tab,setTab]=useState("oracle");
  return(<div style={{background:CL.bg,color:CL.tx,fontFamily:FN,fontSize:17,lineHeight:1.7,minHeight:"100vh"}}>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;0,700;1,400&family=Cinzel:wght@400;600;700&family=EB+Garamond:ital,wght@0,400;0,500;1,400&display=swap" rel="stylesheet"/>
    <div style={{textAlign:"center",padding:"1.8rem 1rem 0.6rem",position:"relative"}}>
      <div style={{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%,-50%)",fontSize:"28vw",color:"rgba(212,160,23,0.015)",fontFamily:"serif",pointerEvents:"none"}}>{"\u05D0"}</div>
      <h1 style={{fontFamily:CI,fontSize:"clamp(1.3rem,3.5vw,2.2rem)",fontWeight:400,color:CL.gold,letterSpacing:"0.12em",textTransform:"uppercase",margin:0}}>Kabbalah Unveiled</h1>
      <p style={{fontFamily:CO,fontSize:"0.9rem",color:CL.dm,fontStyle:"italic",margin:"0.2rem 0 0"}}>Reception | Analysis | Ascension</p>
    </div>
    <nav style={{position:"sticky",top:0,zIndex:100,background:"rgba(2,2,3,0.95)",backdropFilter:"blur(12px)",borderBottom:`1px solid ${CL.bo}`,padding:"0.4rem 0"}}>
      <div style={{display:"flex",justifyContent:"center",gap:"0.4rem",flexWrap:"wrap",maxWidth:900,margin:"0 auto",padding:"0 0.3rem"}}>
        {TABS.map(t=><button key={t.id} onClick={()=>setTab(t.id)} style={{background:"none",border:"none",color:tab===t.id?CL.gold:CL.dm,fontFamily:CI,fontSize:"0.55rem",letterSpacing:"0.1em",textTransform:"uppercase",cursor:"pointer",padding:"0.2rem 0.35rem",borderBottom:tab===t.id?`1px solid ${CL.gold}`:"1px solid transparent"}}>{t.lb}</button>)}
      </div>
    </nav>
    <div style={{maxWidth:900,margin:"0 auto",padding:"1.2rem 1.2rem 3rem"}}>
      {tab==="oracle"&&<OracleTab/>}
      {tab==="word"&&<WordTab/>}
      {tab==="phrase"&&<PhraseTab/>}
      {tab==="compare"&&<CompTab/>}
      {tab==="elements"&&<ElemTab/>}
      {tab==="practices"&&<PracTab/>}
      {tab==="history"&&<HistTab/>}
    </div>
    <footer style={{textAlign:"center",padding:"1rem",fontFamily:CI,fontSize:"0.5rem",letterSpacing:"0.1em",color:CL.dm,textTransform:"uppercase"}}>Kabbalah Unveiled | 118 Elements | Ancient Wisdom</footer>
  </div>);
}
