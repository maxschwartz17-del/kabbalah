const CACHE_NAME = 'kabbalah-v1';
const OFFLINE_URLS = [
  '/',
  '/index.html',
  '/static/js/main.js',
  '/static/css/main.css',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(OFFLINE_URLS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  // For API calls, try network first
  if (event.request.url.includes('api.anthropic.com')) {
    event.respondWith(
      fetch(event.request).catch(() => new Response(JSON.stringify({
        content: [{ type: 'text', text: 'The Oracle is offline. Using local intelligence.' }]
      }), { headers: { 'Content-Type': 'application/json' } }))
    );
    return;
  }
  // For everything else, cache first
  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request).then((response) => {
      const clone = response.clone();
      caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
      return response;
    }))
  );
});
