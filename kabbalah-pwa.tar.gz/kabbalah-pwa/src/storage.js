// Storage adapter - works with localStorage in PWA, window.storage in Claude artifacts
const isArtifact = typeof window !== 'undefined' && window.storage && typeof window.storage.get === 'function';

export const store = {
  get: async (key) => {
    if (isArtifact) {
      try { return await window.storage.get(key); } catch(e) { return null; }
    }
    try {
      const v = localStorage.getItem(key);
      return v !== null ? { value: v } : null;
    } catch(e) { return null; }
  },
  set: async (key, value) => {
    if (isArtifact) {
      try { return await window.storage.set(key, value); } catch(e) { return null; }
    }
    try { localStorage.setItem(key, value); return true; } catch(e) { return null; }
  },
  del: async (key) => {
    if (isArtifact) {
      try { return await window.storage.delete(key); } catch(e) { return null; }
    }
    try { localStorage.removeItem(key); return true; } catch(e) { return null; }
  }
};
