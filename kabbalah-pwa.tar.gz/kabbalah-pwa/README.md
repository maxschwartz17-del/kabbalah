# Kabbalah Unveiled — PWA

A Progressive Web App for Kabbalistic study, analysis, and interpretation.

## Features
- **Oracle** — Conversational guide interpreting synchronicities, visions, and experiences through Kabbalah
- **Word Analyzer** — Full Gematria, Athbash, AIQ BKR analysis of any word
- **Phrase Decoder** — Per-word and total breakdown with Notariqon
- **Comparator** — Side-by-side Qabalistic comparison
- **Elements** — All 118 elements with Sephirotic mapping and esoteric etymologies
- **Voice** — Dictation input and read-aloud for accessibility
- **Offline** — Works without internet (local Oracle intelligence)
- **Online** — Optional Claude API integration for deeper responses
- **Memory** — Persistent storage of analyses, facts, and history

## Quick Start

```bash
npm install
npm run dev
```

Open http://localhost:5173 in your browser.

## Build for Production

```bash
npm run build
```

The `dist/` folder can be deployed to any static host (Vercel, Netlify, GitHub Pages, etc.)

## Deploy to Vercel

```bash
npm i -g vercel
vercel
```

## Deploy to Netlify

Drag the `dist/` folder to netlify.com/drop

## Install as App

On mobile: visit the hosted URL → browser menu → "Add to Home Screen"
On desktop: Chrome will show an install icon in the address bar

## Settings

- **API Key**: Optional. Add your Anthropic API key in Settings to enable Claude-powered Oracle responses. Without it, the Oracle uses a rich local intelligence engine.
- **Facts**: The Oracle remembers numerical facts you teach it (prefix with "remember:")
- **Data**: All data is stored locally on your device only.

## Source Texts Synthesized

1. The Kabbalah Unveiled (S.L. Mathers, 1887)
2. The Constitutions of the Free-Masons (James Anderson, 1723)  
3. Gender Pillars in Jazz Pedagogy (academic paper)
4. The Ancient Wisdom (RevivalOfWisdom, ~120 pages)

## Icons

Replace `public/icon-192.png` and `public/icon-512.png` with your own icons before deploying.
